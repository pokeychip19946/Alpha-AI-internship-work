#----------------------------Dependencies-----------------------------------
from centroidtracker import CentroidTracker
from matplotlib import pyplot as plt
import matplotlib
import cv2
from detect import detect
from datetime import datetime
matplotlib.use('TkAgg')

#------------------Argument parsers--------------------
# ap = argparse.ArgumentParser()
# ap.add_argument("--source", required=True)
# ap.add_argument("--skipframes")
# ap.add_argument("--classnameslist")
# ap.add_argument("--classIDlist")
# ap.add_argument("--conf")
# ap.add_argument("--dwelltime")

# args = vars(ap.parse_args())
#-------------------------------Variables----------------------------------

#------------USER CHANGEBLE VARIABLES----------- 
detectclassname = ['person']  # args["classnameslist"]
detectclassID = [0]  # args["classIDlist"]
video = "Videos/dWELLING.webm" #args["source"]
skip_frames = 5  #args["skipframes"]
dwell_time_limit = 10  #args["dwelltime"]
confidence_threshold=0.6 #args["conf"]

#---------------fixed supported variables----------
totalFrames = 0
cancel_key = "a"
flag=0
flag_plot=0
upd=0
frame = None
x1=None
y1=None
y2=None
x2=None
start_time = datetime.now()
vs = cv2.VideoCapture(video)
ct = CentroidTracker(maxDisappeared=40, maxDistance=50)

#-------------- fixed supported dictionaries-------
trackableObjects = {}
classID = {}
wait = {}
timeinterval_done={}
entry={}
exit={}
dwelltime={}
intruder_starttime={}

#------------------fixed supported lists-------------
IDS=[]
timestamp=[]
intruder_entry_ID = []
#-------------------------helper functions----------------------------------------------------
def selectROI():
	global x1, y1, x2, y2, vs 
	ret, frame = vs.read()
	x1, y1, w, h = cv2.selectROI(frame)
	x2=x1+w
	y2=y1+h
	roi = frame[y1:y2, x1:x2]
	vs=cv2.VideoCapture(video)

def objectID_dwell_time_calculated(objects):
	for (objectID, centroid) in objects.items():

		if entry.get(objectID) == None:
			entry[objectID] = str(updated_time.strftime("%I")) + ":" + str(updated_time.strftime("%M")) + ":" + str(updated_time.strftime("%S"))
			intruder_starttime[objectID]=updated_time
		else:
			exit[objectID] = str(updated_time.strftime("%I")) + ":" + str(updated_time.strftime("%M")) + ":" + str(updated_time.strftime("%S"))
			dwelltime[objectID] = int((updated_time - intruder_starttime[objectID]).total_seconds())

		text = "{}".format(objectID)
		cv2.rectangle(frame, (centroid[0] - 10, centroid[1] - 25), (centroid[0] + 60, centroid[1] - 3), (0, 0, 255), -1)
		cv2.putText(frame, text, (centroid[0] - 10, centroid[1] - 10), cv2.cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255),2, cv2.LINE_AA)


#------------------------------Start of while loop----------------------------------------------
selectROI()
while True:
	ret, frame = vs.read()
	if ret == 0:
		break
	frame=frame[y1:y2,x1:x2]
	rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
	rects = []
	rectclass = []
	if totalFrames % skip_frames == 0:
		trackers = cv2.MultiTracker_create()
		trackerclass = []
		success, detection, frame = detect(image_to_be_classified=frame, classes=detectclassID, conf_thres=confidence_threshold)
		if success == 1:
			number_of_detection = detection.shape[0]
			for i in range(number_of_detection - 1):
				startX = int(float(detection[i + 1][0]))
				startY = int(float(detection[i + 1][1]))
				endX = int(float(detection[i + 1][2])) - startX
				endY = int(float(detection[i + 1][3])) - startY
				box = (startX, startY, endX, endY)
				tracker = cv2.TrackerCSRT_create()
				trackers.add(tracker, frame, box)
				trackerclass.append(detection[i + 1][4])
	else:
		iteration = -1
		(success, boxes) = trackers.update(frame)
		for box in boxes:
			iteration += 1
			(x, y, w, h) = [int(v) for v in box]
			cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
			rects.append((x, y, (x + w), (y + h)))
			rectclass.append(trackerclass[iteration])

	objects, classes, classID = ct.update(rects, rectclass)
	updated_time=datetime.now()
	elapsed_time=int((updated_time-start_time).total_seconds())+1
	objectID_dwell_time_calculated(objects)
	cv2.imshow("Frame", frame)
	key = cv2.waitKey(1)
	if key == ord(cancel_key):
		break
	totalFrames += 1
#------------------------------Visualization setup---------------------------------

def prepare_data_for_visualization():
	intruder_entry_ID=list(entry.keys())
	for ID in intruder_entry_ID:
		IDS.append(ID)
		IDS.append(ID)
		timestamp.append(entry[ID])
		timestamp.append(exit[ID])

def setting_color():
	plt.figure(facecolor='#1B2631')
	ax = plt.axes()
	ax.set_facecolor("#1B2631")
	ax.tick_params(axis='x', colors='#F2F4F4', rotation = 90)
	ax.tick_params(axis='y', colors='#F2F4F4')
	plt.title("Suspicious dwelling time of people",color='#E74C3C',fontweight="bold")
	plt.xlabel("Suspect's ID -->",color='#FDFEFE',fontweight="bold")
	plt.ylabel("Time-stamp (HR:MIN:SEC) -->",color='#FDFEFE',fontweight="bold")


def create_data_visualization():
	global flag_plot,upd
	for i in range(len(entry.keys())):
		particularID = IDS[upd:upd + 2]
		entry_exit = timestamp[upd:upd + 2]
		upd += 2
		if dwelltime.get(particularID[0]) > dwell_time_limit: 
			plt.plot(particularID, entry_exit, color= "#F20F0F",linewidth=10)
		else:
			plt.plot(particularID, entry_exit, color= "#0FF256",linewidth=10)
		if flag_plot==0:
			plt.plot([particularID[0]], [entry_exit[0]], marker='v', markerfacecolor='black', markeredgecolor='black',label='Entry Time')
			plt.plot([particularID[1]], [entry_exit[1]], marker='^', markerfacecolor='black', markeredgecolor='black',label='Exit Time')
			flag_plot=1
		
		else:
			plt.plot([particularID[0]], [entry_exit[0]], marker='v', markerfacecolor='black', markeredgecolor='black')
			plt.plot([particularID[1]], [entry_exit[1]], marker='^', markerfacecolor='black', markeredgecolor='black')

		plt.text(particularID[0],entry_exit[0],f"{dwelltime[particularID[0]]} sec",color='#E74C3C',verticalalignment='center',fontweight="bold")


def suspicious_dwelling_detection_graph():
	setting_color()
	prepare_data_for_visualization()
	create_data_visualization()
	plt.legend()
	plt.show()


suspicious_dwelling_detection_graph()
#---------------------------------------END----------------------------------------
