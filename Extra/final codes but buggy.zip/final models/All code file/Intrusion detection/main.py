#----------------------------Dependencies-----------------------------------
from centroidtracker import CentroidTracker
from trackableobject import TrackableObject
from imutils.video import FPS
from matplotlib import pyplot as plt
import matplotlib
import numpy as np
import cv2
from detect import detect
from datetime import datetime
matplotlib.use('TkAgg')

#-------------------------------Variables----------------------------------
classID = {}
detectclassname = ['person']
detectclassID = [0]
video = "Videos/Intrusion detection 8_trim.mp4"
skip_frames =2
vs = cv2.VideoCapture(video)
ct = CentroidTracker(maxDisappeared=40, maxDistance=50)
trackableObjects = {}
totalFrames = 0
fps = FPS().start()
wait = {}
flag = 0
start_time = datetime.now()
timeinterval_done={}
entry={}
exit={}
dwelltime={}
intruder_starttime={} #for convinience
flag=0
firstframe=None
frame = None

#------------------------------Start of while loop----------------------------------------------

def print_intruder_path():
	flag=0
	for intruder in entry.keys():  #for all intruders
		centroidlist=trackableObjects[intruder].centroids #for each Intruder's centroids list
		for intruder_centroid in range(len(centroidlist)-1):
			cv2.line(firstframe, tuple(centroidlist[intruder_centroid]), tuple(centroidlist[intruder_centroid+1]), (60,76,231), thickness=3)
			if flag==0:
				cv2.putText(firstframe, f"Intruder({intruder}) Enters", (centroidlist[intruder_centroid][0],centroidlist[intruder_centroid][1]+1), cv2.FONT_HERSHEY_COMPLEX, 0.5, (3,255,149), 2)
				flag=1
		cv2.putText(firstframe, f"Intruder({intruder}) Exits",(centroidlist[len(centroidlist)-1][0], centroidlist[len(centroidlist)-1][1] + 1),cv2.FONT_HERSHEY_COMPLEX, 0.5, (3,255,149), 2)
	cv2.imshow("window", firstframe)

#User's choice for selecting ROI
x1=None
y1=None
y2=None
x2=None
ret, frame = vs.read()
x1, y1, w, h = cv2.selectROI(frame)
x2=x1+w
y2=y1+h
roi = frame[y1:y2, x1:x2]
vs=cv2.VideoCapture(video)
while True:
	image = np.zeros((512, 512, 3))
	ret, frame = vs.read()
	if ret == 0:
		break
	frame=frame[y1:y2,x1:x2]

	if flag==0:
		firstframe=frame
		flag=1

	rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
	rects = []
	rectclass = []
	if totalFrames % skip_frames == 0:
		trackers = cv2.MultiTracker_create()
		trackerclass = []
		success, detection, frame = detect(image_to_be_classified=frame, classes=detectclassID, conf_thres=0.4)
		if success == 1:
			print("Detection FOUND")
		else:
			print("DETECTION NOT FOUND!")
		if success == 1:
			number_of_detection = detection.shape[0]
			for i in range(number_of_detection - 1):
				startX = int(float(detection[i + 1][0]))
				startY = int(float(detection[i + 1][1]))
				endX = int(float(detection[i + 1][2])) - startX
				endY = int(float(detection[i + 1][3])) - startY
				box = (startX, startY, endX, endY)
				tracker = cv2.TrackerCSRT_create()
				trackers.add(tracker, frame, box)
				trackerclass.append(detection[i + 1][4])
	else:
		iteration = -1
		(success, boxes) = trackers.update(frame)
		for box in boxes:
			iteration += 1
			(x, y, w, h) = [int(v) for v in box]
			cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
			rects.append((x, y, (x + w), (y + h)))
			rectclass.append(trackerclass[iteration])

	objects, classes, classID, getclassid = ct.update(rects, rectclass)
	updated_time=datetime.now()
	elapsed_time=int((updated_time-start_time).total_seconds())+1


	for (objectID, centroid) in objects.items():

		if entry.get(objectID) == None:
			entry[objectID] = str(updated_time.strftime("%I")) + ":" + str(updated_time.strftime("%M")) + ":" + str(updated_time.strftime("%S"))
			intruder_starttime[objectID]=updated_time
		else:
			exit[objectID] = str(updated_time.strftime("%I")) + ":" + str(updated_time.strftime("%M")) + ":" + str(updated_time.strftime("%S"))
			dwelltime[objectID] = int((updated_time - intruder_starttime[objectID]).total_seconds())

		to = trackableObjects.get(objectID, None)
		if to is None:
			to = TrackableObject(objectID, centroid, classes[objectID])
		to.counted = True
		to.centroids.append(centroid)
		trackableObjects[objectID] = to
		text = "ID {}".format(objectID)
		cv2.putText(frame, text, (centroid[0] - 10, centroid[1] - 10),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
		cv2.circle(frame, (centroid[0], centroid[1]), 4, (0, 255, 0), -1)
		ycoord = 0
		for i in range(len(detectclassname)):
			if getclassid == 0:
				break
			if classID.get(detectclassname[i], None) != None:
				countofclass = classID[detectclassname[i]].split(" ")[1]
				text = f"{detectclassname[i]}(Intruder): {countofclass}"
				cv2.putText(image, text, (0, ycoord + 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
				ycoord += 30
	cv2.imshow("Frame", frame)
	cv2.imshow("Count", image)
	key = cv2.waitKey(1)
	if key == ord("a"):
		break
	totalFrames += 1
	fps.update()
	countclass = [0] * len(detectclassID)
	index = 0
	for i in range(len(detectclassID)):
		if getclassid == 0:
			continue
		if classID.get(detectclassname[i], None) != None:
			t = classID[detectclassname[i]]
			t = t.split(" ")[1]
			countclass[index] = int(t)
			index += 1
# -----------------------End of while loop-------------------------------
vs.release()
cv2.destroyAllWindows()


intruder_entry_ID=list(entry.keys())
IDS=[]
timestamp=[]
for ID in intruder_entry_ID:
	IDS.append(ID)
	IDS.append(ID)
	timestamp.append(entry[ID])
	timestamp.append(exit[ID])


#------------------------------Visualizations---------------------------------
def setting_color():
	ax = plt.axes()
	ax.set_facecolor("#1B2631")
	ax.tick_params(axis='x', colors='#F2F4F4')
	ax.tick_params(axis='y', colors='#F2F4F4')

color = ['#F4D03F', '#E74C3C', '#7D3C98', '#27AE60']

def intrusion_duration():
	plt.figure(facecolor='#1B2631')
	setting_color()
	upd=0
	plt.title("Every intruder's entry and exit time",color='#E74C3C',fontweight="bold")
	plt.xlabel("Intruder's ID -->",color='#FDFEFE',fontweight="bold")
	plt.ylabel("Time-stamp (HR:MIN:SEC) -->",color='#FDFEFE',fontweight="bold")
	index=-1
	markerlist=['^','v']
	flag_plot=0
	for i in range(len(entry.keys())):
		particularID = IDS[upd:upd + 2]
		entry_exit = timestamp[upd:upd + 2]
		upd += 2
		index+=1
		plt.plot(particularID, entry_exit, color=color[index],linewidth=10)
		if flag_plot==0:
			plt.plot([particularID[0]], [entry_exit[0]], marker='v', markerfacecolor='black', markeredgecolor='black',label='Entry Time')
			plt.plot([particularID[1]], [entry_exit[1]], marker='^', markerfacecolor='black', markeredgecolor='black',label='Exit Time')
			flag_plot=1
		else:
			plt.plot([particularID[0]], [entry_exit[0]], marker='v', markerfacecolor='black', markeredgecolor='black')
			plt.plot([particularID[1]], [entry_exit[1]], marker='^', markerfacecolor='black', markeredgecolor='black')

		plt.text(particularID[0],entry_exit[0],f"Duration = {dwelltime[particularID[0]]} sec",color='#E74C3C',verticalalignment='center',fontweight="bold")
	plt.legend()
	plt.show()

print_intruder_path()
intrusion_duration()
fps.stop()
print("Elapsed time: {:.2f}".format(fps.elapsed()))
print("Approx. FPS: {:.2f}".format(fps.fps()))
#---------------------------------------END----------------------------------------