from centroidtracker import CentroidTracker
from trackableobject import TrackableObject
from imutils.video import FPS
import numpy as np
import dlib
import cv2
from detect import detect

video="Videos/market.mp4"
skip_frames=30
# vs = cv2.VideoCapture(video)
# while True:
#     ret, frame = vs.read()
#     x1, y1, w, h = cv2.selectROI(frame)
#     x2=x1+w
#     y2=y1+h
#     roi = frame[y1:y2, x1:x2]
#     break
# #ROI selected!

# print(y1,y2,x1,x2)
vs = cv2.VideoCapture(video)
writer = None
W = None
H = None
ct = CentroidTracker(maxDisappeared=40, maxDistance=50)
trackers = []
trackableObjects = {}
totalFrames = 0
totalDown = 0
totalUp = 0
fps = FPS().start()
CNTT=0
width = int(vs.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(vs.get(cv2.CAP_PROP_FRAME_HEIGHT))
res=(int(width), int(height))
fourcc = cv2.VideoWriter_fourcc(*'XVID')
writer = cv2.VideoWriter("savepeeps.avi", fourcc, 20.0,res)

while True:
	# grab the next frame and handle if we are reading from either
	# VideoCapture or VideoStream
	ret,frame = vs.read()

	if ret==0:
		break
	frame = frame[203:743,503:1279]
	if ret==0:
		break
	# frame = imutils.resize(frame, width=500)
	rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
	# print(frame.shape)
	W=frame.shape[1]
	H=frame.shape[0]
	status = "Waiting"
	rects = []
	if totalFrames % skip_frames == 0:
		status = "Detecting"
		trackers = []
		success,detection,frame=detect(image_to_be_classified=frame,classes=[0],conf_thres=0.6)
		if success==1:
			CNTT+=1
			print("Detection FOUND",CNTT)
		else:
			print("DETECTION NOT FOUND!")
		if success==1:
			number_of_detection=detection.shape[0]
			for i in range(number_of_detection-1):
				startX = int(float(detection[i+1][0]))
				startY = int(float(detection[i+1][1]))
				endX = int(float(detection[i+1][2]))
				endY = int(float(detection[i+1][3]))

				tracker = dlib.correlation_tracker()
				rect = dlib.rectangle(startX, startY, endX, endY)
				tracker.start_track(rgb, rect)
				trackers.append(tracker)
	else:
		for tracker in trackers:
			status = "Tracking"
			tracker.update(rgb)
			pos = tracker.get_position()

			startX = int(float(pos.left()))
			startY = int(float(pos.top()))
			endX = int(float(pos.right()))
			endY = int(float(pos.bottom()))
			rects.append((startX, startY, endX, endY))
	hei=H // 2
	cv2.line(frame, (0, hei), (W, hei), (0, 0,255), 5)
	objects = ct.update(rects)

	for (objectID, centroid) in objects.items():
		to = trackableObjects.get(objectID, None)
		if to is None:
			to = TrackableObject(objectID, centroid)
		else:
			y = [c[1] for c in to.centroids]
			direction = centroid[1] - np.mean(y)
			to.centroids.append(centroid)
			if not to.counted:
				if direction < 0 and centroid[1] < ((H // 2)):
					totalUp += 1
					to.counted = True
				elif direction > 0 and centroid[1] >( (H // 2)):
					totalDown += 1
					to.counted = True
		trackableObjects[objectID] = to


		text = "ID {}".format(objectID)
		cv2.putText(frame, text, (centroid[0] - 10, centroid[1] - 10),
					cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
		cv2.circle(frame, (centroid[0], centroid[1]), 4, (0, 255, 0), -1)

	info = [
		("Up", totalUp),
		("Down", totalDown),
		("Status", status),
	]

	for (i, (k, v)) in enumerate(info):
		text = "{}: {}".format(k, v)
		cv2.putText(frame, text, (0, H - (((i+1)*30))), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
	writer.write(frame)

	cv2.imshow("Frame", frame)
	key = cv2.waitKey(25)
	if key == ord("a"):
		break
	totalFrames += 1
	fps.update()
fps.stop()
print("Elapsed time: {:.2f}".format(fps.elapsed()))
print("Approx. FPS: {:.2f}".format(fps.fps()))
writer.release()
vs.release()
cv2.destroyAllWindows()