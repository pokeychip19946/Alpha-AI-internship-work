# ----------------------------Dependencies-----------------------------------
from centroidtracker import CentroidTracker
from matplotlib import pyplot as plt
import cv2
from detect import detect
from datetime import datetime
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
import matplotlib
from EasyROI import EasyROI
matplotlib.use('TkAgg')

#------------------Helper functions-------------------------------
def point_of_intersection(A, B, C, D):
	#equation of line1
	a1 = B[1] - A[1]
	b1 = A[0] - B[0]
	c1 = a1 * (A[0]) + b1 * (A[1])
	# equation of line1
	a2 = D[1] - C[1]
	b2 = C[0] - D[0]
	c2 = a2 * (C[0]) + b2 * (C[1])
	determinant = a1 * b2 - a2 * b1
	if (determinant == 0):
		return 0
	else:
		x = (b2 * c1 - b1 * c2) / determinant
		y = (a1 * c2 - a2 * c1) / determinant
		return (int(x), int(y))


def check_wrong_lane_violation(centroid):

	for i in range(number_of_offset_line - 1):
		#intersec_i is the point of intersection b/w objectcentroid's horizontal line (across the width of the frame) and (ith) lane's left line
		intersec_i = point_of_intersection((0, centroid[1]), (width, centroid[1]), (lane_dict[i][0][0], lane_dict[i][0][1]),(lane_dict[i][1][0], lane_dict[i][1][1]))
		# intersec_i is the point of intersection b/w objectcentroid's horizontal line (across the width of the frame) and (ith) lane's right lane
		intersec_i1 = point_of_intersection((0, centroid[1]), (width, centroid[1]),(lane_dict[i + 1][0][0], lane_dict[i + 1][0][1]),(lane_dict[i + 1][1][0], lane_dict[i + 1][1][1]))

		if centroid[0] > intersec_i[0] and centroid[0] < intersec_i1[0] and i == 0 and classes.get(objectID) != "motorcycle":
			laneviolateclass[objectID] = 1
			wrong_lane[objectID] = 1

		elif centroid[0] > intersec_i[0] and centroid[0] < intersec_i1[0] and i == 1 and classes.get(objectID) != "car":
			laneviolateclass[objectID] = 1
			wrong_lane[objectID] = 1

		elif centroid[0] > intersec_i[0] and centroid[0] < intersec_i1[0] and i == 2 and (classes.get(objectID) != "truck" or classes.get(objectID) != "bus"):
			laneviolateclass[objectID] = 1
			wrong_lane[objectID] = 1

    	#If the vehicle changes the lane and goes to it's allowed lane, then stop blinking violation sign
		if centroid[0] > intersec_i[0] and centroid[0] < intersec_i1[0] and i == 0 and classes.get(objectID) == "motorcycle":
			laneviolateclass[objectID] = 0

		elif centroid[0] > intersec_i[0] and centroid[0] < intersec_i1[0] and i == 1 and classes.get(objectID) == "car":
			laneviolateclass[objectID] = 0

		elif centroid[0] > intersec_i[0] and centroid[0] < intersec_i1[0] and i == 2 and (classes.get(objectID) == "truck" or classes.get(objectID) == "bus"):
			laneviolateclass[objectID] = 0

def count_lane_violations(objectID):
	if count_done.get(objectID) == None:
		count_done[objectID] = 1
		if laneviolationcount.get(classes[objectID]) == None:
			laneviolationcount[classes[objectID]] = 1
		else:
			laneviolationcount[classes[objectID]] += 1

def blink_violation_image(objectID):
	if classes[objectID] == "car":
		warningsignimage = cv2.imread("dataset/no_car1.png")
	elif classes[objectID] == "bus":
		warningsignimage = cv2.imread("dataset/no_bus1.png")
	elif classes[objectID] == "truck":
		warningsignimage = cv2.imread("dataset/no_truck1.png")
	elif classes[objectID] == "motorcycle":
		warningsignimage = cv2.imread("dataset/no_bike1.png")

	warningsignimage = cv2.resize(warningsignimage, (28, 28))
	warningsignimage_height, warningsignimage_width, _ = warningsignimage.shape

	if (centroid[1] + warningsignimage_height - 1) < frame.shape[0] and (centroid[0] + warningsignimage_width - 1) < frame.shape[1]:
		frame[centroid[1]:(centroid[1] + warningsignimage_height),centroid[0]:(centroid[0] + warningsignimage_width)] = warningsignimage

def data_preparation_for_timestamp_visualization(elapsed_time):
	if elapsed_time%5==0 and elapsed_time>0 and timeinterval_done.get(elapsed_time)==None and classID!=None:
		lane_temp = []

		#List preparation
		for eachclass in detectclassname:
			if laneviolationcount.get(eachclass)!=None:
				lane_temp.append(laneviolationcount[eachclass])
			else:
				lane_temp.append(0)
		if timeinterval_done.get(elapsed_time)==None:
			timeinterval_done[elapsed_time]=1

		laneviolcnt_interval[str(updated_time.strftime("%I")) + ":" + str(updated_time.strftime("%M")) + ":" + str(updated_time.strftime("%S"))] = lane_temp


#----------------------------Argument parsers----------------------------
# ap = argparse.ArgumentParser()
# ap.add_argument("--speedlimit", required=True)
# ap.add_argument("--realdistance", required=True)
# ap.add_argument("--source", required=True)
# ap.add_argument("--skipframes")
# ap.add_argument("--classnameslist")
# ap.add_argument("--classIDlist")
# ap.add_argument("--conf")
# args = vars(ap.parse_args())
# ---------------------------------------------User customized-------------------------------------------------------------------------------------------------------------------
detectclassname = ['car', 'motorcycle', 'bus', 'truck'] #args["classnameslist"]
detectclassID = [2, 3, 5, 7] #args["classIDlist"]
video = "Videos/Lane_detecttion10_Trim_Trim.mp4" #args["source"]
skip_frames = 5 #args["skipframes"]
confidence_threshold=0.58 #args["conf"]

#-------------------------------Fixed variable-------------------------------------------------
classID = {}
classes={}
vs = cv2.VideoCapture(video)
ct = CentroidTracker(maxDisappeared=40, maxDistance=50)
trackableObjects = {}
totalFrames = 0
start_time = datetime.now()
timeinterval_done = {}
blink_circle = {}
wrong_lane={}
count_done = {}
lane_dict = {}
laneviolationcount={}
laneviolateclass = {}
laneviolcnt_interval={}

# ------------------------------Draw ROI and ROI dependencies ----------------------------------------------
#Take region of interest
ret, frame = vs.read()
x1, y1, w, h = cv2.selectROI(frame)
x2 = x1 + w
y2 = y1 + h
frame = frame[y1:y2, x1:x2]


#Draw 4 lanes(bike,car,truck/bus)
roi_helper = EasyROI(verbose=True)
number_of_offset_line = 4
line_roi = roi_helper.draw_line(frame, number_of_offset_line)
frame_temp = roi_helper.visualize_roi(frame, line_roi)

#Store each lane's coordinates in a dictionary
for i in range(number_of_offset_line):
	line_coordinates = [line_roi['roi'][i]['point1'], line_roi['roi'][i]['point2']]
	lane_dict[i] = line_coordinates
	cv2.line(frame, lane_dict[i][0], lane_dict[i][1], (188, 255, 0), 3)


# ------------------------------Traverse the video frames one by one----------------------------------------------
while True:
	ret, frame = vs.read()
	if ret == 0:
		break
	#crop the frame acc. to it's ROI
	frame = frame[y1:y2, x1:x2]
	rects = []
	rectclass = []
	if totalFrames % skip_frames == 0:
		trackers = cv2.MultiTracker_create()
		trackerclass = []
		success, detection, frame = detect(image_to_be_classified=frame, classes=detectclassID, conf_thres=confidence_threshold)
		if success == 1:
			number_of_detection = detection.shape[0]
			for i in range(number_of_detection - 1):
				startX = int(float(detection[i + 1][0]))
				startY = int(float(detection[i + 1][1]))
				endX = int(float(detection[i + 1][2])) - startX
				endY = int(float(detection[i + 1][3])) - startY
				box = (startX, startY, endX, endY)
				tracker = cv2.TrackerCSRT_create()
				trackers.add(tracker, frame, box)
				if detection[i+1][4] == "motorcycle":
					detection[i + 1][4]="bike"
				trackerclass.append(detection[i + 1][4])
	else:
		iteration = -1
		(success, boxes) = trackers.update(frame)
		for box in boxes:
			iteration += 1
			(x, y, w, h) = [int(v) for v in box]
			cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
			rects.append((x, y, (x + w), (y + h)))
			rectclass.append(trackerclass[iteration])

	objects, classes, classID = ct.update(rects, rectclass)
	updated_time = datetime.now()
	elapsed_time = int((updated_time - start_time).total_seconds()) + 1
	width = frame.shape[1]

	for i in range(number_of_offset_line):
		cv2.line(frame, lane_dict[i][0], lane_dict[i][1], (188, 255, 0), 3)
		vehicle=None
		exceed_x=50
		if(i==0):
			vehicle="bike"
		elif(i==1):
			vehicle="car"
		elif(i==2):
			vehicle="truck/bus"
		else:
			continue
		temp=int(((lane_dict[i+1][0][0] - lane_dict[i][0][0])/2))
		x_coordinate=temp + lane_dict[i][0][0] - 20
		y_coordinate=10

		if(vehicle=="truck/bus"):
			x_coordinate-=10
			exceed_x=90



		cv2.rectangle(frame, (x_coordinate - 3, y_coordinate - 10), (x_coordinate + exceed_x, y_coordinate + 2), (44, 0, 116), -1)
		cv2.putText(frame,vehicle,(x_coordinate,y_coordinate),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255),1, cv2.LINE_AA)

	for (objectID, centroid) in objects.items():
		check_wrong_lane_violation(centroid)
		if laneviolateclass.get(objectID) == 1:
			count_lane_violations(objectID)
			if blink_circle.get(objectID)==None:
				blink_circle[objectID]=0
			else:
				blink_circle[objectID]+=1
			if (blink_circle[objectID] % 2 == 0):
				blink_violation_image(objectID)
		cv2.rectangle(frame, (centroid[0] - 10, centroid[1] - 25), (centroid[0] + 50, centroid[1] - 3), (0, 0, 255), -1)
		cv2.putText(frame, "{}".format(objectID), (centroid[0] - 10, centroid[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255),2, cv2.LINE_AA)
	updated_time = datetime.now()
	elapsed_time = int((updated_time - start_time).total_seconds())
	data_preparation_for_timestamp_visualization(elapsed_time)
	cv2.imshow("Frame", frame)
	key = cv2.waitKey(1)
	if key == ord("a"):
		break
	totalFrames += 1

vs.release()
cv2.destroyAllWindows()

# ------------------------------Structuring data and visualizing data---------------------------------

def count_for_each_time_stamp():
	values = list(laneviolcnt_interval.values())
	keys = list(laneviolcnt_interval.keys())

	for i in reversed(range(len(values))):
		if i == 0:
			continue
		for j in range(len(detectclassname)):
			values[i][j] -= values[i - 1][j]
		laneviolcnt_interval[keys[i]] = values[i]
	return values,keys

def setting_color():
	ax = plt.axes()
	ax.set_facecolor("#1B2631")
	ax.tick_params(axis='x', colors='#F2F4F4')
	ax.tick_params(axis='y', colors='#F2F4F4')

color = ['#F4D03F', '#E74C3C', '#7D3C98', '#27AE60']

def change_image_in_graph(objectID):
	if classes[objectID] == "car":
		warningsignimage = "dataset/no_car1.png"
	elif classes[objectID] == "bus":
		warningsignimage = "dataset/no_bus1.png"
	elif classes[objectID] == "truck":
		warningsignimage = "dataset/no_truck1.png"
	elif classes[objectID] == "motorcycle":
		warningsignimage = "dataset/no_bike1.png"
	zoom = 0.07
	img = plt.imread(warningsignimage)
	im = OffsetImage(img, zoom=zoom)
	return im

def ID_vs_violation():
	#Data preparation for line chart
	ID = []
	traffic_light_violation = []
	for everyclass in detectclassname:
		if classID.get(everyclass) == None:
			continue
		highestID = classID[everyclass]
		highestID_number = int(highestID.split(" ")[1])
		for idsofeverclass in range(highestID_number):
			classid = str(everyclass) + " " + str(idsofeverclass)
			if wrong_lane.get(classid) == 1:
				traffic_light_violation.append("Traffic-Lane violation")
				ID.append(classid)
			else:
				traffic_light_violation.append("No Traffic-Lane violation")
				ID.append(classid)

	#define figure,title,xlabel,ylabel,ticks,axes_colour
	plt.figure(facecolor='#1B2631')
	setting_color()
	plt.xlabel("Vehicles ID", color='#F4D03F', fontweight="bold")
	plt.ylabel("Traffic-lane violation(Yes/No)", color='#F4D03F', fontweight="bold")
	plt.title("Class-wise Traffic-Lane violation detection", color='#F2F4F4', fontweight="bold", fontsize=13)
	plt.xticks(rotation=90, fontsize=9)

	#plot the graph
	plt.plot(ID, traffic_light_violation)
	f1 = 0
	f2 = 0
	color = '#E74C3C'

	#for defining marker labels, over-write the individual points on the same plot and add labels of the marker
	for i in range(len(ID)):
		if traffic_light_violation[i] == "Traffic-Lane violation":
			plt.gca().add_artist(AnnotationBbox(change_image_in_graph(ID[i]), (ID[i], traffic_light_violation[i]), xycoords='data', frameon=False))
			#This is done to add the label only once for a particular marker
			if f1 == 0:
				plt.plot([ID[i]], [traffic_light_violation[i]], marker="o", markerfacecolor='red', markeredgecolor='red',label="Traffic-Lane violation")
				f1 = 1
		else:
			plt.plot([ID[i]], [traffic_light_violation[i]], marker="*", markerfacecolor='#F39C12',markeredgecolor='#F39C12', markersize=14)
			# This is done to add the label only once for a particular marker
			if f2 == 0:
				plt.plot([ID[i]], [traffic_light_violation[i]], marker="*", markerfacecolor='#F39C12',markeredgecolor='#F39C12',label="No Traffic-Lane violation")
				f2 = 1
	#Define legend
	plt.legend()


def no_of_trafficlane_bytimestamp_line():
	#Take analyzed data
	values,keys=count_for_each_time_stamp()

	#define figure,title,xlabel,ylabel,ticks,axes_colour
	plt.figure(facecolor='#1B2631')
	setting_color()
	plt.title("Number of traffic-lane violation by types of vehicles on a timestamp", color='#F2F4F4')
	plt.xlabel("Time stamp", color='#F4D03F', fontweight="bold")
	plt.ylabel("Number of traffic-lane violation at a particular time-stamp", color='#F4D03F', fontweight="bold")
	plt.xticks(rotation=90, fontsize=9)

	#Print violation counts on the graph
	ids = list(laneviolcnt_interval.keys())
	countbytime = list(laneviolcnt_interval.values())
	markerscolorlist = ['#F4D03F', '#229954', '#E74C3C', '#3498DB']
	for i in range(len(ids)):
		for j in range(len(detectclassname)):
			plt.text(ids[i],countbytime[i][j]+float(0.1),f"{countbytime[i][j]}",verticalalignment='center',color=markerscolorlist[j],fontweight="bold")

	#Create data according to line plot and finally plot the data!
	ax = plt.subplot()
	markershapelist=['o','v','^','*']
	for eachclass in range(len(detectclassname)):
		countofparticularclass=[]
		eachtimestamp=[]
		iteration=0
		for countofeachclass in values:
			countofparticularclass.append(countofeachclass[eachclass])
			eachtimestamp.append(keys[iteration])
			iteration+=1
		ax.plot(eachtimestamp,countofparticularclass,label=detectclassname[eachclass],marker=markershapelist[eachclass],markerfacecolor=markerscolorlist[eachclass],markeredgecolor=markerscolorlist[eachclass],color=markerscolorlist[eachclass],markersize=12)

	#Define legend
	plt.legend()


no_of_trafficlane_bytimestamp_line()
ID_vs_violation()
#Show all the visualizations!
plt.show()






1.