from centroidtracker import CentroidTracker
from trackableobject import TrackableObject
from imutils.video import FPS
import numpy as np
import dlib
import cv2
from detect import detect


highlight={}
image = np.zeros((512, 512, 3))
video="Videos/wrong_way.mp4"
skip_frames=10
vs = cv2.VideoCapture(video)
x1=183
y1=125
x2=216
y2=155
lanecentroid=(x1+int((x2-x1)/2),int(y1))
vs = cv2.VideoCapture(video)
writer = None
W = None
H = None
ct = CentroidTracker(maxDisappeared=40, maxDistance=50)
trackers = []
trackableObjects = {}
totalFrames = 0
totalDown = 0
totalUp = 0
fps = FPS().start()
CNTT=0
width = int(vs.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(vs.get(cv2.CAP_PROP_FRAME_HEIGHT))
res=(int(width), int(height))
fourcc = cv2.VideoWriter_fourcc(*'XVID')
writer = cv2.VideoWriter("savepeeps.avi", fourcc, 20.0,res)

while True:
	ret,frame = vs.read()
	if ret==0:
		break
	frame=frame[91:473,418:957]
	rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
	W=frame.shape[1]
	H=frame.shape[0]
	rects = []
	if totalFrames % skip_frames == 0:
		trackers = []
		success,detection,frame=detect(image_to_be_classified=frame,classes=[2,7],conf_thres=0.3)
		if success==1:
			CNTT+=1
			print("Detection FOUND",CNTT)
		else:
			print("DETECTION NOT FOUND!")
		if success==1:
			number_of_detection=detection.shape[0]
			for i in range(number_of_detection-1):
				startX = int(float(detection[i+1][0]))
				startY = int(float(detection[i+1][1]))
				endX = int(float(detection[i+1][2]))
				endY = int(float(detection[i+1][3]))

				tracker = dlib.correlation_tracker()
				rect = dlib.rectangle(startX, startY, endX, endY)
				tracker.start_track(rgb, rect)
				trackers.append(tracker)
	else:
		for tracker in trackers:
			status = "Tracking"
			tracker.update(rgb)
			pos = tracker.get_position()

			startX = int(float(pos.left()))
			startY = int(float(pos.top()))
			endX = int(float(pos.right()))
			endY = int(float(pos.bottom()))
			rects.append((startX, startY, endX, endY))
	hei=H // 2
	# cv2.line(frame, (0, hei), (W, hei), (0, 0,255), 5)
	objects = ct.update(rects)


	for (objectID, centroid) in objects.items():
		wrongwayleft=0
		wrongwayright=0
		to = trackableObjects.get(objectID, None)
		if to is None:
			to = TrackableObject(objectID, centroid)
		else:
			y = [c[1] for c in to.centroids]
			direction = centroid[1] - np.mean(y)
			to.centroids.append(centroid)
			if not to.counted:

				if direction < 0:

					totalUp += 1
					if(centroid[0] + 10 < lanecentroid[0]):
						wrongwayleft=1
					to.counted = True
				elif direction > 0:

					totalDown += 1
					if (centroid[0] > lanecentroid[0]):
						wrongwayright = 1
					to.counted = True
		trackableObjects[objectID] = to
		if(wrongwayright==1 or wrongwayleft==1):
			highlight[objectID]=1



		if(highlight.get(objectID,None)!=None):
			cv2.circle(frame, (centroid[0], centroid[1]), 17, (0, 0, 255), 2)
			cv2.putText(image,f"Highlighted car ID {objectID} from wrong way detected!", (0, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)


		text = "ID {}".format(objectID)
		cv2.putText(frame, text, (centroid[0] - 10, centroid[1] - 10),
					cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
		cv2.circle(frame, (centroid[0], centroid[1]), 4, (0, 255, 0), -1)
		# print(lanecentroid)
		cv2.putText(frame, "Lane division point!", (lanecentroid[0]-50, lanecentroid[1]+40),
				cv2.FONT_HERSHEY_SIMPLEX, 0.5, (50, 50, 255), 2)
		cv2.circle(frame, lanecentroid, 10, (0, 0, 255), -1)


	writer.write(frame)

	cv2.imshow("Frame", frame)
	cv2.imshow("wrong way detection", image)
	image = np.zeros((512, 512, 3))
	key = cv2.waitKey(25)
	if key == ord("a"):
		break
	totalFrames += 1
	fps.update()
fps.stop()
print("Elapsed time: {:.2f}".format(fps.elapsed()))
print("Approx. FPS: {:.2f}".format(fps.fps()))
writer.release()
vs.release()
cv2.destroyAllWindows()