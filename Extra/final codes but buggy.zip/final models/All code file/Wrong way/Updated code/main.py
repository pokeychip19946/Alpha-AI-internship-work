# ----------------------------Dependencies-----------------------------------
from centroidtracker import CentroidTracker
from trackableobject import TrackableObject
import numpy as np
import cv2
from detect import detect
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
from matplotlib import pyplot as plt
import matplotlib
from datetime import datetime
matplotlib.use('TkAgg')


# -----------------------------Helper functions-------------------------------
def calculate_direction_of_vehicle(to):
	y = [c[1] for c in to.centroids]
	direction = centroid[1] - np.mean(y)
	to.direction = direction

#------------------Argument parsers--------------------
# ap = argparse.ArgumentParser()
# ap.add_argument("--source", required=True)
# ap.add_argument("--skipframes")
# ap.add_argument("--classnameslist")
# ap.add_argument("--classIDlist")
# ap.add_argument("--conf")
# args = vars(ap.parse_args())

# ------------------User customizable variables-----------------------
video = "Videos/wrong_way.mp4" #args["source"]
skip_frames = 5 #args["skipframes"]
detectclassname = ['car', 'bus', 'truck', "motorcycle"]  # args["classnameslist"]
detectclassid = [2, 5, 7, 3]  # args["classIDlist"]
confidence_threshold=0.3 #args["conf"]

# -----------------Fixed variables-----------------------------
highlight = {}
vs = cv2.VideoCapture(video)
ct = CentroidTracker(maxDisappeared=30, maxDistance=50)
trackers = []
trackerclass = []
trackableObjects = {}
totalFrames = 0
totalDown = 0
totalUp = 0
wait_some_frames = {}
frame_roi=[]
start_time=datetime.now()
timeinterval_done={}
wrong_wayviolationcount={}
wrong_wayviolcnt_interval={}
blink_circle={}
count_done={}
# ---------------------ROI and lane division point-----------

# ROI
ret, frame = vs.read()
x1, y1, w, h = cv2.selectROI(frame)
x2 = x1 + w
y2 = y1 + h
frame_roi=[y1,y2,x1,x2]
frame = frame[frame_roi[0]:frame_roi[1], frame_roi[2]:frame_roi[3]]


# Lane division point
x1, y1, w, h = cv2.selectROI(frame)
x2 = x1 + w
y2 = y1 + h
lanecentroid = (x1 + int((x2 - x1) / 2), int(y1))

# --------------------Traverse video frames one by one---------------------
while True:
	ret, frame = vs.read()
	if ret == 0:
		break
	frame = frame[frame_roi[0]:frame_roi[1], frame_roi[2]:frame_roi[3]]
	# frame=frame[91:473,418:957]
	W = frame.shape[1]
	H = frame.shape[0]
	rects = []
	rectclass = []
	if totalFrames % skip_frames == 0:
		trackers = cv2.MultiTracker_create()
		trackerclass = []
		success, detection, frame = detect(image_to_be_classified=frame, classes=detectclassid, conf_thres=confidence_threshold)
		if success == 1:
			number_of_detection = detection.shape[0]
			for i in range(number_of_detection - 1):
				startX = int(float(detection[i + 1][0]))
				startY = int(float(detection[i + 1][1]))
				endX = int(float(detection[i + 1][2])) - startX
				endY = int(float(detection[i + 1][3])) - startY
				box = (startX, startY, endX, endY)
				tracker = cv2.TrackerCSRT_create()
				trackers.add(tracker, frame, box)
				trackerclass.append(detection[i + 1][4])
	else:
		iteration = -1
		(success, boxes) = trackers.update(frame)
		for box in boxes:
			iteration += 1
			(x, y, w, h) = [int(v) for v in box]
			cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
			rects.append((x, y, (x + w), (y + h)))
			rectclass.append(trackerclass[iteration])

	objects, classes, classID = ct.update(rects, rectclass)


	for (objectID, centroid) in objects.items():
		wrongwayleft = 0
		wrongwayright = 0
		to = trackableObjects.get(objectID, None)
		#Wait some frames to collect certain amount of centroids for having an correct direction
		if wait_some_frames.get(objectID) == None:
			wait_some_frames[objectID] = 1
		else:
			wait_some_frames[objectID] += 1
		if to is None:
			to = TrackableObject(objectID, centroid)
		else:
			to.centroids.append(centroid)
			#if certain amount of centroids are there, then calculate direction
			if wait_some_frames[objectID] > 30:
				if to.direction is None or to.direction == 0.0:
					calculate_direction_of_vehicle(trackableObjects[objectID])
			#Checking whether the car has violated wrong way or not!
			if not to.counted:
				if to.direction != None and to.direction < 0:
					totalUp += 1
					if (centroid[0] + 10 < lanecentroid[0]):
						wrongwayleft = 1
					to.counted = True
				elif to.direction != None and to.direction > 0:
					totalDown += 1
					if (centroid[0] > lanecentroid[0]):
						wrongwayright = 1
					to.counted = True
		trackableObjects[objectID] = to
		if (wrongwayright == 1 or wrongwayleft == 1):
			highlight[objectID] = 1

		#Blinking the violation sign
		if (highlight.get(objectID, None) != None):

			if count_done.get(objectID)==None:
				count_done[objectID]=1
				if wrong_wayviolationcount.get(classes[objectID])==None:
					wrong_wayviolationcount[classes[objectID]]=1
				else:
					wrong_wayviolationcount[classes[objectID]]+=1

			if blink_circle.get(objectID)==None:
				blink_circle[objectID]=0
			else:
				blink_circle[objectID]+=1

			if (blink_circle[objectID]% 2 == 0):
				warningsignimage = cv2.imread("dataset/wrong_way.png")
				warningsignimage = cv2.resize(warningsignimage, (28, 28))
				warningsignimage_height, warningsignimage_width, _ = warningsignimage.shape
				if (centroid[1] + warningsignimage_height - 1) < frame.shape[0] and (centroid[0] + warningsignimage_width - 1) < frame.shape[1]:
					frame[centroid[1]:(centroid[1] + warningsignimage_height),
				centroid[0]:(centroid[0] + warningsignimage_width)] = warningsignimage

		cv2.rectangle(frame, (centroid[0] - 10, centroid[1] - 25), (centroid[0] + 50, centroid[1] - 3), (0, 0, 255), -1)
		cv2.putText(frame, "{}".format(objectID), (centroid[0] - 10, centroid[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
					(0, 255, 255), 2, cv2.LINE_AA)
		cv2.rectangle(frame, (lanecentroid[0] - 50, lanecentroid[1] + 25), (lanecentroid[0] + 105, lanecentroid[1] + 50),
					  (116, 20, 0), -1)
		cv2.putText(frame, "Lane division point!",(lanecentroid[0] - 50, lanecentroid[1] + 40), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1,cv2.LINE_AA)
		cv2.circle(frame, lanecentroid, 10, (0, 0, 255), -1)

		updated_time = datetime.now()
		elapsed_time = int((updated_time - start_time).total_seconds())

		#Data preparation for timestamp visualization
		if elapsed_time % 5 == 0 and elapsed_time > 0 and timeinterval_done.get(
				elapsed_time) == None and classID != None:
			wrong_way_temp = []

			for eachclass in detectclassname:
				if wrong_wayviolationcount.get(eachclass) != None:
					wrong_way_temp.append(wrong_wayviolationcount[eachclass])
				else:
					wrong_way_temp.append(0)
			if timeinterval_done.get(elapsed_time) == None:
				timeinterval_done[elapsed_time] = 1

			wrong_wayviolcnt_interval[str(updated_time.strftime("%I")) + ":" + str(updated_time.strftime("%M")) + ":" + str(
				updated_time.strftime("%S"))] = wrong_way_temp

	cv2.imshow("Frame", frame)
	key = cv2.waitKey(25)
	if key == ord("a"):
		break
	totalFrames += 1

vs.release()
cv2.destroyAllWindows()


# -----------------------------------------Data preparation and visualization-------------------------------

#Data preparation for visualization
values= list(wrong_wayviolcnt_interval.values())
keys = list(wrong_wayviolcnt_interval.keys())
for i in reversed(range(len(values))):
	if i ==0:
		continue
	for j in range(len(detectclassname)):
		values[i][j]-=values[i-1][j]
	wrong_wayviolcnt_interval[keys[i]] = values[i]

#Visualization
def setting_color():
	ax = plt.axes()
	ax.set_facecolor("#1B2631")
	ax.tick_params(axis='x', colors='#F2F4F4')
	ax.tick_params(axis='y', colors='#F2F4F4')

def line_graph():
	# Data preparation
	ID = []
	wrong_way = []
	for everyclass in detectclassname:
		if classID.get(everyclass) == None:
			continue
		highestID = classID[everyclass]
		highestID_number = int(highestID.split(" ")[1])
		for idsofeverclass in range(highestID_number):
			classid = str(everyclass) + " " + str(idsofeverclass)
			ID.append(classid)
			if highlight.get(classid) == 1:
				wrong_way.append("Wrong-way violation")
			else:
				wrong_way.append("No Wrong-way violation")

	#Configuring the details
	plt.figure(facecolor='#1B2631')
	setting_color()
	plt.xticks(rotation=90, fontsize=9)
	plt.plot(ID, wrong_way)
	plt.title("Class-wise Wrong_way detection", color='#F2F4F4', fontweight="bold", fontsize=13)
	plt.xlabel("Vehicles ID", color='#F4D03F', fontweight="bold")
	plt.ylabel("Wrong way detection(Yes/No)", color='#F4D03F', fontweight="bold")
	f1 = 0
	f2 = 0


	image = 'dataset/wrong_way.png'
	zoom = 0.07
	img = plt.imread(image)
	im = OffsetImage(img, zoom=zoom)
	#for defining marker labels, over-write the individual points on the same plot and add labels of the marker
	for i in range(len(ID)):
		if wrong_way[i] == "Wrong-way violation":
			plt.gca().add_artist(AnnotationBbox(im, (ID[i], wrong_way[i]), xycoords='data', frameon=False))
			# This is done to add the label only once for a particular marker
			if f1 == 0:
				plt.plot([ID[i]], [wrong_way[i]], marker="o", markerfacecolor='red', markeredgecolor='red',
						 label="Wrong way detection")
				f1 = 1
		else:
			plt.plot([ID[i]], [wrong_way[i]], marker="*", markerfacecolor='#F39C12', markeredgecolor='#F39C12',
					 markersize=14)
			# This is done to add the label only once for a particular marker
			if f2 == 0:
				plt.plot([ID[i]], [wrong_way[i]], marker="*", markerfacecolor='#F39C12', markeredgecolor='#F39C12',
						 label="No Wrong_Way violation")
				f2 = 1
	#Defining the legend
	plt.legend()

	#Scaling
	scale_factor = 1
	xmin, xmax = plt.xlim()
	ymin, ymax = plt.ylim()
	plt.xlim(xmin * scale_factor, xmax * scale_factor)
	plt.ylim(ymin * scale_factor, ymax * scale_factor)


def no_of_illegal_Uturn_bytimestamp_line():
	# Configuring the details
	plt.figure(facecolor='#1B2631')
	setting_color()
	plt.title("Number of Wrong way violations by types of vehicles on a timestamp",color='#F2F4F4')
	plt.xlabel("Time stamp", color='#F4D03F', fontweight="bold")
	plt.ylabel("Number of Wrong way violations at a particular time-stamp", color='#F4D03F', fontweight="bold")
	plt.xticks(rotation=90, fontsize=9)
	#Show count of violations by time-stamp
	ids = list(wrong_wayviolcnt_interval.keys())
	countbytime = list(wrong_wayviolcnt_interval.values())
	markerscolorlist = ['#F4D03F', '#229954', '#E74C3C', '#3498DB']
	for i in range(len(ids)):
		for j in range(len(detectclassname)):
			plt.text(ids[i],countbytime[i][j]+float(0.05),f"{countbytime[i][j]}",verticalalignment='center',color=markerscolorlist[j],fontweight="bold")

	#Create data according to line plot and finally plot the data!
	ax = plt.subplot()
	markershapelist=['o','v','^','*']
	for eachclass in range(len(detectclassname)):
		countofparticularclass=[]
		eachtimestamp=[]
		iteration=0

		for countofeachclass in values:
			countofparticularclass.append(countofeachclass[eachclass])
			eachtimestamp.append(keys[iteration])
			iteration+=1
		ax.plot(eachtimestamp,countofparticularclass,label=detectclassname[eachclass],marker=markershapelist[eachclass],markerfacecolor=markerscolorlist[eachclass],markeredgecolor=markerscolorlist[eachclass],color=markerscolorlist[eachclass],markersize=12)
	#Defining the legend
	plt.legend()

line_graph()
no_of_illegal_Uturn_bytimestamp_line()
plt.show()
