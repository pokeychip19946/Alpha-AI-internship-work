from centroidtracker import CentroidTracker
from trackableobject import TrackableObject
from imutils.video import FPS
import numpy as np
import dlib
import cv2
from detect import detect
import time
from datetime import datetime
video = "Videos/illegalparking1.mp4"
skip_frames = 50
vs = cv2.VideoCapture(video)
object_time = {}
updated_centroid = {}
limit = 20
vs = cv2.VideoCapture(video)
ct = CentroidTracker(maxDisappeared=40, maxDistance=50)
trackers = []
trackableObjects = {}
totalFrames=0
while True:
    # grab the next frame and handle if we are reading from either
    # VideoCapture or VideoStream
    ret, frame = vs.read()

    if ret==0:
        break
    wid = 1080
    hig = 640
    frame = cv2.resize(frame, (wid, hig))
    if ret == 0:
        break
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    W = frame.shape[1]
    H = frame.shape[0]
    status = "Waiting"
    rects = []
    if totalFrames % skip_frames == 0:
        status = "Detecting"
        trackers = []
        success, detection, frame = detect(image_to_be_classified=frame, classes=[2,3,5,7], conf_thres=0.4)
        if success == 1:
            print("Detection FOUND")
        else:
            print("DETECTION NOT FOUND!")
        if success == 1:
            number_of_detection = detection.shape[0]
            for i in range(number_of_detection - 1):
                startX = int(float(detection[i + 1][0]))
                startY = int(float(detection[i + 1][1]))
                endX = int(float(detection[i + 1][2]))
                endY = int(float(detection[i + 1][3]))

                tracker = dlib.correlation_tracker()
                rect = dlib.rectangle(startX, startY, endX, endY)
                tracker.start_track(rgb, rect)
                trackers.append(tracker)
    else:
        for tracker in trackers:
            status = "Tracking"
            tracker.update(rgb)
            pos = tracker.get_position()

            startX = int(float(pos.left()))
            startY = int(float(pos.top()))
            endX = int(float(pos.right()))
            endY = int(float(pos.bottom()))
            rects.append((startX, startY, endX, endY))
    hei = H // 2
    objects = ct.update(rects)

    for (objectID, centroid) in objects.items():
        to = trackableObjects.get(objectID, None)
        if to is None:
            # ts = datetime.now()
            to = TrackableObject(objectID, centroid)
            updated_centroid[objectID] = centroid
        else:

            min_x = updated_centroid[objectID][0] - limit
            min_y = updated_centroid[objectID][1] - limit
            max_x = updated_centroid[objectID][0] + limit
            max_y = updated_centroid[objectID][1] + limit

            # check if the vehicle is moving or not
            if centroid[0] >= min_x and centroid[0] <= max_x and centroid[1] >= min_y and centroid[1] <= max_y:
                # this means vehicle is illegally parked, so we start the timer
                if object_time.get(objectID, None) == None:
                    ts1 = datetime.now()
                    object_time[objectID] = ts1
                ts2 = datetime.now()
                timeInSeconds = abs((ts2 - (object_time[objectID])).total_seconds())
                print("for ", objectID, "time = ", timeInSeconds)

                if timeInSeconds >= 20:
                    cv2.putText(frame, f"ID {objectID} illegally parked for {timeInSeconds:.2f} seconds", (centroid[0]-100, centroid[1]+30),
                                cv2.FONT_HERSHEY_DUPLEX, 0.5, (9, 237, 214), 1)

            else:
                updated_centroid[objectID] = centroid
                object_time[objectID] = None

        trackableObjects[objectID] = to
        text = "ID {}".format(objectID)
        cv2.putText(frame, text, (centroid[0] - 10, centroid[1] - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        cv2.circle(frame, (centroid[0], centroid[1]), 4, (0, 255, 0), -1)

    cv2.imshow("Frame", frame)
    key = cv2.waitKey(1)
    if key == ord("a"):
        break
    totalFrames += 1
vs.release()
cv2.destroyAllWindows()