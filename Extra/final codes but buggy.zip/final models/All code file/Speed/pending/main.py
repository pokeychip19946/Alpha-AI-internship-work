# ----------------------------Dependencies-----------------------------------
from centroidtracker import CentroidTracker
from trackableobject import TrackableObject
import numpy as np
import cv2
from detect import detect
from datetime import datetime
from matplotlib import pyplot as plt
import matplotlib
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
import argparse
matplotlib.use('TkAgg')
#-----------------------------Helper functions-------------------------------
def define_speed_estimation_zone(H):
	update = 0
	key = 'A'
	for i in range(4):
		speed_estimation_zone[key] = int(update)
		temp = ord(key) + 1
		key = chr(temp)
		update += int((H / 4))

def calculate_direction_of_vehicle(to):
	y = [c[1] for c in to.centroids]
	direction = centroid[1] - np.mean(y)
	to.direction = direction

def save_vehicle_timestamp_and_position_for_positive_direction(to):
	if to.timestamp["A"] == 0:
		if centroid[1] > speed_estimation_zone["A"]:
			to.timestamp["A"] = ts
			to.position["A"] = centroid[1]
	elif to.timestamp["B"] == 0:
		if centroid[1] > speed_estimation_zone["B"]:
			to.timestamp["B"] = ts
			to.position["B"] = centroid[1]
	elif to.timestamp["C"] == 0:
		if centroid[1] > speed_estimation_zone["C"]:
			to.timestamp["C"] = ts
			to.position["C"] = centroid[1]
	elif to.timestamp["D"] == 0:
		if centroid[1] > speed_estimation_zone["D"]:
			to.timestamp["D"] = ts
			to.position["D"] = centroid[1]
			to.lastPoint = True

def save_vehicle_timestamp_and_position_for_negative_direction(to):
	if to.timestamp["D"] == 0:
		if centroid[1] < speed_estimation_zone["D"]:
			to.timestamp["D"] = ts
			to.position["D"] = centroid[1]

	elif to.timestamp["C"] == 0:
		if centroid[1] < speed_estimation_zone["C"]:
			to.timestamp["C"] = ts
			to.position["C"] = centroid[1]

	elif to.timestamp["B"] == 0:
		if centroid[1] < speed_estimation_zone["B"]:
			to.timestamp["B"] = ts
			to.position["B"] = centroid[1]

	elif to.timestamp["A"] == 0:
		if centroid[1] < speed_estimation_zone["A"]:
			to.timestamp["A"] = ts
			to.position["A"] = centroid[1]

def calculate_individual_speeds_for_zones(to):
	estimatedSpeeds = []
	for (i, j) in points:
		d = to.position[j] - to.position[i]
		distanceInPixels = abs(d)
		if distanceInPixels == 0:
			continue
		t = to.timestamp[j] - to.timestamp[i]
		timeInSeconds = abs(t.total_seconds())
		timeInHours = timeInSeconds / (60 * 60)
		distanceInMeters = distanceInPixels * meterPerPixel
		distanceInKM = distanceInMeters / 1000
		estimatedSpeeds.append(distanceInKM / timeInHours)
	return estimatedSpeeds

def count_speed_violations(to):
	if speedviolationcount.get(classes[objectID]) == None:
		speedviolationcount[classes[objectID]] = 1
	else:
		speedviolationcount[classes[objectID]] += 1

def data_preparation_for_timestamp_visualization(elapsed_time):
	if elapsed_time%60==0 and elapsed_time>0 and timeinterval_done.get(elapsed_time)==None and classID!=None:
		speed_temp = []
		#List preparation
		for eachclass in detectclassname:
			if speedviolationcount.get(eachclass)!=None:
				speed_temp.append(speedviolationcount[eachclass])
			else:
				speed_temp.append(0)
		if timeinterval_done.get(elapsed_time)==None:
			timeinterval_done[elapsed_time]=1
		speedviolcnt_interval[str(updated_time.strftime("%I"))+":"+str(updated_time.strftime("%M"))] = speed_temp

#------------------Argument parsers--------------------
# ap = argparse.ArgumentParser()
# ap.add_argument("--speedlimit", required=True)
# ap.add_argument("--realdistance", required=True)
# ap.add_argument("--source", required=True)
# ap.add_argument("--skipframes")
# ap.add_argument("--classnameslist")
# ap.add_argument("--classIDlist")
# args = vars(ap.parse_args())


#------------------------User customizable variables,list-----------------------------
detectclassname = ['car', 'bus', 'truck',"motorcycle"] #args["classnameslist"]
speed_violation_threshold=20 #args["speedlimit"]
detectclassid=[2,5,7,3] #args["classIDlist"]
speed_violation_threshold=20 #args["speedlimit"]
real_distance=100 #args["realdistance"]
video="Videos/Speed Violation.mp4" #args["source"]
skip_frames=10 #args["skipframes"]
# ------------------------ Fixed variables,list,dictionaries,objects-------------------------------------------------------------------------------------------------------------------
speedviolcnt_interval = {}
timeinterval_done={}
speedviolationcount={}
start_time = datetime.now()
speed_estimation_zone={"A": None, "B": None, "C": None, "D": None}
image=np.zeros((512,512,3))
vs = cv2.VideoCapture(video)
ct = CentroidTracker(maxDisappeared=40, maxDistance=50)
trackers = []
trackableObjects = {}
totalFrames = 0
points = [("A", "B"), ("B", "C"), ("C", "D")]
classID = {}
wait_some_frames={}
#-----------------------------------Region of interest-------------------------------------------------
ret,frame=vs.read()
x1,y1,w,h=cv2.selectROI(frame)
x2=x1+w
y2=y1+h
# ------------------------------Traverse the video frames one by one----------------------------------------------
while True:
	ret,frame = vs.read()
	if ret==0:
		break
	ts = datetime.now()
	#Cropping the frame according to ROI
	frame=frame[y1:y2,x1:x2]
	H=frame.shape[0]
	#Defining the speed estimation zone
	define_speed_estimation_zone(H)
	meterPerPixel = real_distance / H
	rects = []
	rectclass=[]
	if totalFrames % skip_frames == 0:
		trackers = cv2.MultiTracker_create()
		trackerclass=[]
		success,detection,frame=detect(image_to_be_classified=frame,classes=detectclassid,conf_thres=0.62)
		if success==1:
			number_of_detection=detection.shape[0]
			for i in range(number_of_detection-1):
				startX = int(float(detection[i+1][0]))
				startY = int(float(detection[i+1][1]))
				endX = int(float(detection[i + 1][2])) - startX
				endY = int(float(detection[i + 1][3])) - startY
				box = (startX, startY, endX, endY)
				tracker = cv2.TrackerCSRT_create()
				trackers.add(tracker, frame, box)
				trackerclass.append(detection[i + 1][4])
	else:
		iteration = -1
		(success, boxes) = trackers.update(frame)
		for box in boxes:
			iteration += 1
			(x, y, w, h) = [int(v) for v in box]
			cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
			rects.append((x, y, (x + w), (y + h)))
			rectclass.append(trackerclass[iteration])

	objects, classes, classID = ct.update(rects,rectclass)
	updated_time=datetime.now()

	for (objectID, centroid) in objects.items():
		# Wait certain frames, so that good amount of centroids are there for calcuating direction
		if wait_some_frames.get(objectID) == None:
			wait_some_frames[objectID] = 1
		else:
			wait_some_frames[objectID] += 1

		to = trackableObjects.get(objectID, None)
		if to is None:
			to = TrackableObject(objectID, centroid)
		elif not to.estimated:
			to.centroids.append(centroid)
			# Checking if we have certain amount of centroids
			if wait_some_frames[objectID] > 20:
				if to.direction is None or to.direction == 0.0:
					y = [c[1] for c in to.centroids]
					direction = centroid[1] - np.mean(y)
					to.direction = direction
			# Noting position and timestamp of the vehicle(in positive direction) when it reaches a speed estimation zone
			if to.direction != None and to.direction > 0:
				if to.timestamp["A"] == 0:
					if centroid[1] > speed_estimation_zone["A"]:
						to.timestamp["A"] = ts
						to.position["A"] = centroid[1]
				elif to.timestamp["B"] == 0:
					if centroid[1] > speed_estimation_zone["B"]:
						to.timestamp["B"] = ts
						to.position["B"] = centroid[1]
				elif to.timestamp["C"] == 0:
					if centroid[1] > speed_estimation_zone["C"]:
						to.timestamp["C"] = ts
						to.position["C"] = centroid[1]
				elif to.timestamp["D"] == 0:
					if centroid[1] > speed_estimation_zone["D"]:
						to.timestamp["D"] = ts
						to.position["D"] = centroid[1]
						to.lastPoint = True

			# Noting position and timestamp of the vehicle(in negative direction) when it reaches a speed estimation zone
			elif to.direction != None and to.direction < 0:
				if to.timestamp["D"] == 0:
					if centroid[1] < speed_estimation_zone["D"]:
						to.timestamp["D"] = ts
						to.position["D"] = centroid[1]

				elif to.timestamp["C"] == 0:
					if centroid[1] < speed_estimation_zone["C"]:
						to.timestamp["C"] = ts
						to.position["C"] = centroid[1]

				elif to.timestamp["B"] == 0:
					if centroid[1] < speed_estimation_zone["B"]:
						to.timestamp["B"] = ts
						to.position["B"] = centroid[1]

				elif to.timestamp["A"] == 0:
					if centroid[1] < speed_estimation_zone["A"]:
						to.timestamp["A"] = ts
						to.position["A"] = centroid[1]

			# Calculate the average speed of the vehicle if it has reached the last point and it it's speed is not yet estimated
			if to.lastPoint and not to.estimated:
				estimatedSpeeds = []

				# Calculating individual speeds in b/w speed estimation zones
				for (i, j) in points:
					d = to.position[j] - to.position[i]
					distanceInPixels = abs(d)
					if distanceInPixels == 0:
						continue
					t = to.timestamp[j] - to.timestamp[i]
					timeInSeconds = abs(t.total_seconds())
					timeInHours = timeInSeconds / (60 * 60)
					distanceInMeters = distanceInPixels * meterPerPixel
					distanceInKM = distanceInMeters / 1000
					estimatedSpeeds.append(distanceInKM / timeInHours)

				# Calculating final speed(average speed)
				to.calculate_speed(estimatedSpeeds)
				to.estimated = True

				# Show speed on blank image
				show_speed = "Speed of car ID {objectID}: {speed:.2f} KMPH".format(objectID=objectID,
																				   speed=to.speedKMPH)
				image = np.zeros((512, 512, 3))
				cv2.putText(image, show_speed, (0, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 100, 50), 1, cv2.LINE_AA)

				# Count speed violations and showing on blank image
				if to.speedKMPH >= speed_violation_threshold:
					if speedviolationcount.get(classes[objectID]) == None:
						speedviolationcount[classes[objectID]] = 1
					else:
						speedviolationcount[classes[objectID]] += 1
					violate = f"{objectID} is overspeeding!"
					cv2.putText(image, violate, (0, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 100, 50), 1, cv2.LINE_AA)
		# Putting the object in the dictionary for future reference
		trackableObjects[objectID] = to
		cv2.rectangle(frame, (centroid[0] - 10, centroid[1] - 25), (centroid[0] + 50, centroid[1] - 3), (0, 0, 255), -1)
		cv2.putText(frame, "{}".format(objectID), (centroid[0] - 10, centroid[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
					(0, 255, 255), 2, cv2.LINE_AA)

	updated_time=datetime.now()
	elapsed_time=int((updated_time-start_time).total_seconds())
	data_preparation_for_timestamp_visualization(elapsed_time)
	cv2.imshow("Frame", frame)
	cv2.imshow("show speed",image)
	key = cv2.waitKey(1)
	if key == ord("a"):
		break
	totalFrames += 1

vs.release()
cv2.destroyAllWindows()
# ----------------------------------------Structuring data and visualizing data---------------------------------
def ID_and_speed():
	values = list(speedviolcnt_interval.values())
	keys = list(speedviolcnt_interval.keys())
	return values,keys
def data_preparation_for_ID_vs_speeds():
	#data preparation
	count1=0
	for eachclass in classID.values():
		for countofeachclass in range(int(eachclass.split(" ")[1])):
			if trackableObjects[eachclass.split(" ")[0]+" "+str(countofeachclass)].speedKMPH != None:
				count1+=1
				print(count1,".","trackableObjects[",eachclass.split(" ")[0]+" "+str(countofeachclass),"].speedKMPH=",trackableObjects[eachclass.split(" ")[0]+" "+str(countofeachclass)].speedKMPH)
				if trackableObjects[eachclass.split(" ")[0]+" "+str(countofeachclass)].speedKMPH ==np.float64(np.nan):
					print("YES!")
				if trackableObjects[eachclass.split(" ")[0]+" "+str(countofeachclass)].speedKMPH == float("nan"):
					print("YESSSS!")
	count1 = 0
	for eachclass in classID.values():
		for countofeachclass in range(int(eachclass.split(" ")[1])):
			if trackableObjects[eachclass.split(" ")[0]+" "+str(countofeachclass)].speedKMPH != None:
				count1 += 1
				print(count1,".",int(trackableObjects[eachclass.split(" ")[0]+" "+str(countofeachclass)].speedKMPH))

	speed = [int(trackableObjects[eachclass.split(" ")[0]+" "+str(countofeachclass)].speedKMPH) for eachclass in classID.values() for countofeachclass in range(int(eachclass.split(" ")[1])) if trackableObjects[eachclass.split(" ")[0]+" "+str(countofeachclass)].speedKMPH != None]
	ID = [eachclass.split(" ")[0]+" "+str(countofeachclass) for eachclass in classID.values() for countofeachclass in range(int(eachclass.split(" ")[1])) if trackableObjects[eachclass.split(" ")[0]+" "+str(countofeachclass)].speedKMPH != None]

	return speed,ID

def prepare_data_for_Timestamp_vs_speed_violations():
	values,keys=ID_and_speed()
	for i in reversed(range(len(values))):
		if i ==0:
			continue
		for j in range(len(detectclassname)):
			values[i][j]-=values[i-1][j]
		speedviolcnt_interval[keys[i]] = values[i]

def configure_plot_details():
	ax = plt.axes()
	ax.set_facecolor("#1B2631")
	ax.tick_params(axis='x', colors='#F2F4F4')
	ax.tick_params(axis='y', colors='#F2F4F4')

def take_image_in_graph():
	warningsignimage='dataset/warn.png'
	zoom = 0.07
	img = plt.imread(warningsignimage)
	im = OffsetImage(img, zoom=zoom)
	return im

def Timestamp_vs_speed_violations():
	# Configuring the plot details
	plt.figure(facecolor='#1B2631')
	plt.xticks(rotation=90, fontsize=9)
	configure_plot_details()
	#Defining title,xlabel,ylabel
	plt.title("Number of speed violations by types of vehicles on a timestamp",color='#F2F4F4')
	plt.xlabel("Time stamp",color='#F4D03F',fontweight="bold")
	plt.ylabel("Number of Speed violations at a particular time-stamp",color='#F4D03F',fontweight="bold")

	#Show count of violations by time-stamp
	ids = list(speedviolcnt_interval.keys())
	countbytime = list(speedviolcnt_interval.values())
	markerscolorlist = ['#F4D03F', '#229954', '#E74C3C', '#3498DB']
	for i in range(len(ids)):
		for j in range(len(detectclassname)):
			plt.text(ids[i],countbytime[i][j]+float(0.05),f"{countbytime[i][j]}",verticalalignment='center',color=markerscolorlist[j],fontweight="bold")

	#Create data according to line plot and finally plot the data!
	values, keys = ID_and_speed()
	ax = plt.subplot()
	markershapelist=['o','v','^','*']
	for eachclass in range(len(detectclassname)):
		countofparticularclass=[]
		eachtimestamp=[]
		iteration=0
		for countofeachclass in values:
			countofparticularclass.append(countofeachclass[eachclass])
			eachtimestamp.append(keys[iteration])
			iteration+=1
		ax.plot(eachtimestamp,countofparticularclass,label=detectclassname[eachclass],marker=markershapelist[eachclass],markerfacecolor=markerscolorlist[eachclass],markeredgecolor=markerscolorlist[eachclass],color=markerscolorlist[eachclass],markersize=12)
	#Defining the legend
	plt.legend()

def ID_vs_speeds():
	plt.figure(facecolor='#1B2631')
	plt.xticks(rotation=90, fontsize=9)
	#Configuring the plot details
	configure_plot_details()
	#Take data
	speed,ID=data_preparation_for_ID_vs_speeds()
	# plot the graph
	plt.plot(ID, speed)
	f1 = 0
	f2 = 0

	#Draw the speed violation offset line
	plt.axhline(y=speed_violation_threshold, color='#FF3633', linestyle='--')
	#Defining the title
	plt.title("Speed Limit Graph(Speed vs Vehicle IDs)", color='#F2F4F4', fontweight="bold", fontsize=13)
	#Print speed violation on plot
	plt.text(0, speed_violation_threshold + 0.2, f'Speed Limit({speed_violation_threshold} km/hr)', fontsize=8,color='#FDFEFE', fontweight="bold")
	#Defining xlabels, ylabels
	plt.xlabel("Vehicles ID", color='#F4D03F', fontweight="bold")
	plt.ylabel("Speed of the Vehicle", color='#F4D03F', fontweight="bold")

	#for defining marker labels, over-write the individual points on the same plot and add labels of the marker
	for i in range(len(ID)):
		if int(trackableObjects[ID[i]].speedKMPH) > speed_violation_threshold:
			plt.gca().add_artist(AnnotationBbox(take_image_in_graph(), (ID[i],speed[i]), xycoords='data', frameon=False ))
			# This is done to add the label only once for a particular marker
			if f1 ==0:
				plt.plot(ID[i], speed[i], marker="^", markerfacecolor='red', markeredgecolor='red', label = "Speed imit violated")
				f1 = 1
		else:
			plt.plot(ID[i], speed[i], marker="o", markerfacecolor='green',  markeredgecolor='green',markersize=12)
			# This is done to add the label only once for a particular marker
			if f2 ==0:
				plt.plot(ID[i], speed[i], marker="o", markerfacecolor='green',  markeredgecolor='green', label = "Under speed limit")
				f2 = 1
	#Define the legend
	plt.legend()
	#Show speed of particular vehicle on the graph
	for i in range(len(ID)):
		plt.text(ID[i] ,speed[i]+0.7,f"{speed[i]}",verticalalignment='center',color='#F4D03F',fontsize = 11,fontweight="bold")



ID_vs_speeds()
Timestamp_vs_speed_violations()
plt.show()
