#----------------------------Dependencies-----------------------------------
from centroidtracker import CentroidTracker
from matplotlib import pyplot as plt
import matplotlib
import cv2
from detect import detect
from datetime import datetime
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
from EasyROI import EasyROI
matplotlib.use('TkAgg')

#----------------------------Argument parsers----------------------------
# ap = argparse.ArgumentParser()
# ap.add_argument("--source", required=True)
# ap.add_argument("--skipframes")
# ap.add_argument("--classnameslist")
# ap.add_argument("--classIDlist")
# ap.add_argument("--conf")
#-------------------------------Variables----------------------------------
#------------USER CHANGEABLE VARIABLES-----------
detectclassname = ['car','motorcycle','bus','truck']#args["classnameslist"]
detectclassID = [2,3,5,7] #args["classIDlist"]
video = "Videos/illegal u turn 3.mp4" #args["source"]
skip_frames = 5 #args["skipframes"]
confidence_threshold=0.6 #args["conf"]

#---------------fixed supported variables----------
blink_circle=0
totalFrames = 0
markerscolorlist = ['#F4D03F', '#229954', '#E74C3C', '#3498DB']
warningsignimage=cv2.imread("dataset/no u turn.png")
image = 'dataset/no u turn.png'
zoom = 0.02
x1=None
y1=None
y2=None
x2=None
frame = None

#-------------- fixed supported dictionaries-------

classID = {}
trackableObjects = {}
wait = {}
timeinterval_done={}
previously_below_line={} #before taking U turn
above_line={} #Taking U turn
now_below_line={}  #Took U turn
lane_divider_coord_x_compare={}
uturnviolationcount ={}
uturnviolcnt_interval = {}
count_done = {}
blink_circle = {}

#-------------- fixed supported lists-------
line_coordinates = []
values = []
keys = []
#---------------------------- fixed supported tupple-----------
lane_divider_coord = (0, 0)
start_time = datetime.now()
vs = cv2.VideoCapture(video)
ct = CentroidTracker(maxDisappeared=40, maxDistance=50)

#-------------------------helper functions----------------------------------------------------

def select_offset_line():
	global vs, line_coordinates, frame
	ret, frame = vs.read()
	roi_helper = EasyROI(verbose=True)
	line_roi = roi_helper.draw_line(frame, 1)
	frame_temp = roi_helper.visualize_roi(frame, line_roi)
	line_coordinates=[line_roi['roi'][0]['point1'],line_roi['roi'][0]['point2']]
	cv2.line(frame,line_coordinates[0],line_coordinates[1],(188,255,0),3)


def select_lane_divison_point():
	global x1, y1, x2, y2, lane_divider_coord, frame
	x1, y1, w, h = cv2.selectROI(frame)
	x2=x1+w
	y2=y1+h
	halfx=(x2-x1)/2
	halfy=(y2-y1)/2
	x3=int(halfx)+x1
	y3=int(halfy)+y1
	lane_divider_coord=(x3,y3)

def blink_violation_image(objectID):
	if(blink_circle[objectID] %2 == 0):
		global warningsignimage
		warningsignimage = cv2.resize(warningsignimage, (28, 28))
		warningsignimage_height,warningsignimage_width,_=warningsignimage.shape
		frame[centroid[1]:(centroid[1]+warningsignimage_height),centroid[0]:(centroid[0]+warningsignimage_width)]=warningsignimage

def illegal_u_turn_detection(objectID):
	if centroid[1]>line_coordinates[1][1] and previously_below_line.get(objectID)==None:
		previously_below_line[objectID]=1
		lane_divider_coord_x_compare[objectID]=(centroid[0]<lane_divider_coord[0])


	if previously_below_line.get(objectID)==1 and centroid[1]<line_coordinates[1][1]:
		above_line[objectID]=1

	if above_line.get(objectID)==1 and previously_below_line.get(objectID)==1 and centroid[1]>line_coordinates[1][1] and (centroid[0]<lane_divider_coord[0])!=lane_divider_coord_x_compare[objectID]:
		now_below_line[objectID]=1

	if now_below_line.get(objectID)==1:

		if count_done.get(objectID) == None:
			count_done[objectID] = 1
			if uturnviolationcount.get(classes[objectID]) == None:
				uturnviolationcount[classes[objectID]] = 1

			else:
				uturnviolationcount[classes[objectID]] += 1
		if blink_circle.get(objectID) == None:
			blink_circle[objectID] = 1
		else:
			blink_circle[objectID] += 1
		blink_violation_image(objectID)




#------------------------------Start of while loop----------------------------------------------
select_offset_line()
select_lane_divison_point()

while True:
	ret, frame = vs.read()
	if ret == 0:
		break
	rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
	rects = []
	rectclass = []
	if totalFrames % skip_frames == 0:
		trackers = cv2.MultiTracker_create()
		trackerclass = []
		success, detection, frame = detect(image_to_be_classified=frame, classes=detectclassID, conf_thres=confidence_threshold)
		if success == 1:
			print("Detection FOUND")
		else:
			print("DETECTION NOT FOUND!")
		if success == 1:
			number_of_detection = detection.shape[0]
			for i in range(number_of_detection - 1):
				startX = int(float(detection[i + 1][0]))
				startY = int(float(detection[i + 1][1]))
				endX = int(float(detection[i + 1][2])) - startX
				endY = int(float(detection[i + 1][3])) - startY
				box = (startX, startY, endX, endY)
				tracker = cv2.TrackerCSRT_create()
				trackers.add(tracker, frame, box)
				trackerclass.append(detection[i + 1][4])
	else:
		iteration = -1
		(success, boxes) = trackers.update(frame)
		for box in boxes:
			iteration += 1
			(x, y, w, h) = [int(v) for v in box]
			cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
			rects.append((x, y, (x + w), (y + h)))
			rectclass.append(trackerclass[iteration])

	objects, classes, classID = ct.update(rects, rectclass)
	updated_time=datetime.now()
	elapsed_time=int((updated_time-start_time).total_seconds())+1


	for (objectID, centroid) in objects.items():
		text = "{}".format(objectID)
		cv2.rectangle(frame, (centroid[0] - 10, centroid[1] - 25), (centroid[0] + 50, centroid[1] - 3), (0, 0, 255), -1)
		cv2.putText(frame, text, (centroid[0] - 10, centroid[1] - 10), cv2.cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255),2, cv2.LINE_AA)

		illegal_u_turn_detection(objectID)

	updated_time = datetime.now()
	elapsed_time = int((updated_time - start_time).total_seconds())

	if elapsed_time % 5 == 0 and elapsed_time > 0 and timeinterval_done.get(elapsed_time) == None and classID != None:
		uturn_temp = []

		for eachclass in detectclassname:
			if uturnviolationcount.get(eachclass) != None:
				uturn_temp.append(uturnviolationcount[eachclass])
			else:
				uturn_temp.append(0)
		if timeinterval_done.get(elapsed_time) == None:
			timeinterval_done[elapsed_time] = 1

		uturnviolcnt_interval[str(updated_time.strftime("%I")) + ":" + str(updated_time.strftime("%M")) + ":" + str(
			updated_time.strftime("%S"))] = uturn_temp


	cv2.circle(frame,(lane_divider_coord[0],lane_divider_coord[1]),10,(60,76,231),-1)
	cv2.putText(frame, "Lane division point",(lane_divider_coord[0]-50,lane_divider_coord[1]-10),cv2.FONT_HERSHEY_COMPLEX, 0.4,(42,32,23), 1,cv2.LINE_AA)
	cv2.line(frame,line_coordinates[0],line_coordinates[1],(188,255,0),3)
	cv2.imshow("Frame", frame)
	key = cv2.waitKey(25)
	if key == ord("a"):
		break
	totalFrames += 1
vs.release()
cv2.destroyAllWindows()


#------------------------------Visualizations setup---------------------------------

values= list(uturnviolcnt_interval.values())
keys = list(uturnviolcnt_interval.keys())


for i in reversed(range(len(values))):
	if i ==0:
		continue
	for j in range(len(detectclassname)):
		values[i][j]-=values[i-1][j]
	uturnviolcnt_interval[keys[i]] = values[i]


def setting_color():
	ax = plt.axes()
	ax.set_facecolor("#1B2631")
	ax.tick_params(axis='x', colors='#F2F4F4')
	ax.tick_params(axis='y', colors='#F2F4F4')
	plt.xticks(rotation=90, fontsize=9)


def line_graph():
	global image, zoom
	ID=[]
	U_turn=[]
	for everyclass in detectclassname:
		if classID.get(everyclass)==None:
			continue
		highestID=classID[everyclass]
		highestID_number=int(highestID.split(" ")[1])
		for idsofeverclass in range(highestID_number):
			classid=str(everyclass)+" "+str(idsofeverclass)
			ID.append(classid)
			if now_below_line.get(classid)==1:
				U_turn.append("Illegal U-Turn")
			else:
				U_turn.append("No Illegal U-Turn")

	plt.figure(facecolor='#1B2631')
	setting_color()
	plt.title("Class-wise Illegal U-turn detection", color='#F2F4F4', fontweight="bold", fontsize=13)
	plt.plot(ID, U_turn)
	f1 = 0
	f2 = 0
	color = '#E74C3C'

	# ---------------------------------------------------------
	img = plt.imread(image)
	im = OffsetImage(img, zoom=zoom)
	# ---------------------------------------------------------
	for i in range(len(ID)):
		if U_turn[i]=="Illegal U-Turn":
			plt.gca().add_artist(AnnotationBbox(im, (ID[i], U_turn[i]), xycoords='data', frameon=False))
			if f1 == 0:
				plt.plot([ID[i]],[ U_turn[i]], marker="o", markerfacecolor='red', markeredgecolor='red',
						 label="Illegal U-turn")
				f1 = 1

		else:
			plt.plot([ID[i]],  [U_turn[i]], marker="*", markerfacecolor='#F39C12', markeredgecolor='#F39C12', markersize=14)
			if f2 == 0:
				plt.plot([ID[i]], [U_turn[i]], marker="*", markerfacecolor='#F39C12', markeredgecolor='#F39C12',
						 label="No Illegal U-turn")
				f2 = 1

	plt.legend()

	plt.xlabel("Vehicles ID", color='#F4D03F', fontweight="bold")
	plt.ylabel("Illegal U turn detection(Yes/No)", color='#F4D03F', fontweight="bold")

	scale_factor = 1
	xmin, xmax = plt.xlim()
	ymin, ymax = plt.ylim()
	plt.xlim(xmin * scale_factor, xmax * scale_factor)
	plt.ylim(ymin * scale_factor, ymax * scale_factor)
	plt.show()

def no_of_illegal_Uturn_bytimestamp_line():
	global markerscolorlist  
	plt.figure(num=2,facecolor='#1B2631')
	setting_color()
	plt.title("Number of illegal U-Turn by types of vehicles on a timestamp",color='#F2F4F4')
	ids = list(uturnviolcnt_interval.keys())
	countbytime = list(uturnviolcnt_interval.values())
	for i in range(len(ids)):
		for j in range(len(detectclassname)):
			plt.text(ids[i],countbytime[i][j]+float(0.05),f"{countbytime[i][j]}",verticalalignment='center',color=markerscolorlist[j],fontweight="bold")

	plt.xlabel("Time stamp",color='#F4D03F',fontweight="bold")
	plt.ylabel("Number of illegal U-Turn at a particular time-stamp",color='#F4D03F',fontweight="bold")


	ax = plt.subplot()
	markershapelist=['o','v','^','*']

	for eachclass in range(len(detectclassname)):
		countofparticularclass=[]
		eachtimestamp=[]
		iteration=0

		for countofeachclass in values:
			countofparticularclass.append(countofeachclass[eachclass])
			eachtimestamp.append(keys[iteration])
			iteration+=1
		ax.plot(eachtimestamp,countofparticularclass,label=detectclassname[eachclass],marker=markershapelist[eachclass],markerfacecolor=markerscolorlist[eachclass],markeredgecolor=markerscolorlist[eachclass],color=markerscolorlist[eachclass],markersize=12)
	plt.legend()

no_of_illegal_Uturn_bytimestamp_line()
line_graph()
#---------------------------------------END----------------------------------------





